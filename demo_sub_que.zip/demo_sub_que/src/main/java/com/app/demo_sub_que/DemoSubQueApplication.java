package com.app.demo_sub_que;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoSubQueApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSubQueApplication.class, args);
	}

}
